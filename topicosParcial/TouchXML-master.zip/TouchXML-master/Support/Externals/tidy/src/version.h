/* version information

  (c) 2007-2008 (W3C) MIT, ERCIM, Keio University
  See tidy.h for the copyright notice.

  CVS Info :

    $Author: arnaud02 $ 
    $Date: 2008/08/11 10:13:41 $ 
    $Revision: 1.43 $ 

*/

static const char TY_(release_date)[] = "11 August 2008";
